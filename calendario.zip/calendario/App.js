import React from 'react';
import { View } from 'react-native';
import CalendarioActividades from './components/CalendarioActividades';

const App = () => {
  return (
    <View>
      <CalendarioActividades />
    </View>
  );
}

export default App;

