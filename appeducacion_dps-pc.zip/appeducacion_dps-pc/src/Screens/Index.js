import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

const Inicio = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.welcomeText}>Bienvenido a ESC Educación</Text>
      <Text style={styles.paragraph}>ESC Educacion es una Institucion especializada en impartir cursos de Idioma avanzado, Tecnicos en asistencias contables, Computacion, Administracion de empresas y mas! Gracias por formar parte de nuestra Institucion</Text>
      <View style={styles.imageContainer}>
        <Image
          source={require('../../assets/icons/ESC.jpg')}
          style={styles.image}
          resizeMode="contain"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#FFFFFF',
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  paragraph: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  imageContainer: {
    width: '100%',
    alignItems: 'center',
  },
  image: {
    width: 200,
    height: 200,
  },
});

export default Inicio;

