import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Linking } from 'react-native';

function Biblioteca() {

  const openLink = (url) => {
    Linking.openURL(url);
  };

  const renderLink = (url, text) => {
    return (
      <TouchableOpacity onPress={() => openLink(url)}>
        <Text style={styles.linkText}>{text}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.section}>
        <Text style={[styles.texto, styles.titulo]}>Diplomados en Idiomas:</Text>
        <View style={styles.linkContainer}>
          {renderLink('https://www.uv.mx/pozarica/cadi/files/2019/11/Ingles-1-Tema-1.pdf', 'TÉC. EN IDIOMA INGLÉS')}
          {renderLink('https://proassetspdlcom.cdnstatics2.com/usuaris/libros_contenido/arxius/41/40469_Frances_Facil.pdf', 'TÉC. EN IDIOMA FRANCÉS')}
          {renderLink('https://www.euskadi.eus/contenidos/informacion/dic6_programaciones_por_idioma/es_def/adjuntos/portugues/portugues_A1_c.pdf', 'TÉC. EN IDIOMA PORTUGUÉS')}
        </View>
      </View>
      <View style={styles.section}>
        <Text style={[styles.texto, styles.titulo]}>Diplomados en Informática y Negocios:</Text>
        <View style={styles.linkContainer}>
          {renderLink('https://gc.scalahed.com/recursos/files/r161r/w25469w/ingdelsoftwarelibro9_compressed.pdf', 'TÉC. OPERADOR EJECUTIVO DE SOFTWARE')}
          {renderLink('https://www.conalepveracruz.edu.mx/iniciobackup/wp-content/uploads/2021/03/Mantenimiento-de-equipo-de-cómputo-básico-MÓDULO-PROFESIONAL.pdf', 'TÉC. EN REPARACIÓN Y MANTENIMIENTO DE PC')}
          {renderLink('https://www.colibri.udelar.edu.uy/jspui/bitstream/20.500.12008/307/1/M-CD4103.pdf', 'TÉC. EN CALL CENTER Y MARKETING')}
          {renderLink('https://www.recope.go.cr/wp-content/uploads/2013/10/Asistente-de-Contabilidad.pdf', 'TÉC. ASISTENTE CONTABLE ADMINISTRATIVO WEB')}
          {renderLink('https://www.usac.edu.gt/empleos/archivos/_Anuncio-Asistente-de-Gerencia-Bilingue-noviembre-2019--TRANSOIL.pdf', 'TÉC. SECRETARIADO EN GERENCIA BILINGÜE')}
          {renderLink('https://fad.es/wp-content/uploads/2019/05/Manual-de-atención-al-Cliente.pdf', 'TÉC. ASISTENTE EJECUTIVO DE ATENCIÓN AL CLIENTE')}
        </View>
      </View>
      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>Contactos 2237-0901 o esc.educacion@gmail.com</Text>
        <Text style={styles.footerText2}>Educación de calidad con Proyeccion Social</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  section: {
    alignItems: 'center',
    marginBottom: 20,
  },
  linkContainer: {
    alignItems: 'center',
  },
  linkText: {
    fontSize: 20,
    marginBottom: 10,
    textDecorationLine: 'underline',
    color: '#00f',
    fontWeight: 'bold',
  },
  titulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  // Footer Estilos Copiados de Acerca
  footer: {
    position: 'absolute', // Para que el footer esté fijo en la parte inferior
    bottom: 0,
    width: '100%',
    backgroundColor: '#2E57D1',
    paddingVertical: 10,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    color: '#FFF',
  },
  footerText2: {
    fontSize: 12,
    color: '#F88B74',
  }
});

export default Biblioteca;
