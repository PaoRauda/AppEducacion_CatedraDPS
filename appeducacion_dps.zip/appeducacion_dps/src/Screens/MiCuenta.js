import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

function MiCuenta() {

  return (
    <View>
      <Text>Micuenta</Text>
    </View>
  );
}
export default MiCuenta;